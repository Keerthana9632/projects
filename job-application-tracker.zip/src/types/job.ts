export type JobStage = 'applied' | 'interview' | 'offer' | 'rejected';

export interface JobApplication {
  id: string;
  company: string;
  role: string;
  stage: JobStage;
  notes: string;
  interviewDate?: string;
  appliedDate: string;
}

export const STAGES: { key: JobStage; label: string }[] = [
  { key: 'applied', label: 'Applied' },
  { key: 'interview', label: 'Interview' },
  { key: 'offer', label: 'Offer' },
  { key: 'rejected', label: 'Rejected' },
];
