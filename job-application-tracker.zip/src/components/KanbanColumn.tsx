import { JobApplication, JobStage } from '@/types/job';
import JobCard from './JobCard';
import { Plus } from 'lucide-react';
import { useState } from 'react';

interface KanbanColumnProps {
  stage: JobStage;
  label: string;
  jobs: JobApplication[];
  onEdit: (job: JobApplication) => void;
  onDragStart: (e: React.DragEvent, jobId: string) => void;
  onDrop: (e: React.DragEvent, stage: JobStage) => void;
  onAddClick: (stage: JobStage) => void;
}

const columnColors: Record<JobStage, string> = {
  applied: 'bg-column-applied border-primary/20',
  interview: 'bg-column-interview border-amber-300/40',
  offer: 'bg-column-offer border-accent/30',
  rejected: 'bg-column-rejected border-destructive/20',
};

const KanbanColumn = ({ stage, label, jobs, onEdit, onDragStart, onDrop, onAddClick }: KanbanColumnProps) => {
  const [dragOver, setDragOver] = useState(false);

  return (
    <div
      className={`rounded-xl border-2 p-3 min-h-[400px] flex flex-col transition-colors ${columnColors[stage]} ${dragOver ? 'ring-2 ring-primary/40' : ''}`}
      onDragOver={e => { e.preventDefault(); setDragOver(true); }}
      onDragLeave={() => setDragOver(false)}
      onDrop={e => { setDragOver(false); onDrop(e, stage); }}
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <h3 className="font-display font-bold text-sm text-foreground">{label}</h3>
          <span className="bg-foreground/10 text-foreground text-xs font-semibold rounded-full px-2 py-0.5">
            {jobs.length}
          </span>
        </div>
        <button
          onClick={() => onAddClick(stage)}
          className="text-muted-foreground hover:text-primary transition-colors"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>
      <div className="flex flex-col gap-2 flex-1">
        {jobs.map(job => (
          <JobCard key={job.id} job={job} onEdit={onEdit} onDragStart={onDragStart} />
        ))}
      </div>
    </div>
  );
};

export default KanbanColumn;
