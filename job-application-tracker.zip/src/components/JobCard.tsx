import { JobApplication } from '@/types/job';
import { CalendarDays, GripVertical, Pencil } from 'lucide-react';

interface JobCardProps {
  job: JobApplication;
  onEdit: (job: JobApplication) => void;
  onDragStart: (e: React.DragEvent, jobId: string) => void;
}

const JobCard = ({ job, onEdit, onDragStart }: JobCardProps) => {
  return (
    <div
      draggable
      onDragStart={e => onDragStart(e, job.id)}
      className="bg-card border rounded-lg p-3 cursor-grab active:cursor-grabbing shadow-sm hover:shadow-md transition-shadow group"
    >
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-1.5">
          <GripVertical className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
          <h4 className="font-display font-semibold text-sm text-card-foreground">{job.company}</h4>
        </div>
        <button onClick={() => onEdit(job)} className="text-muted-foreground hover:text-primary transition-colors">
          <Pencil className="w-3.5 h-3.5" />
        </button>
      </div>
      <p className="text-xs text-muted-foreground mt-1 ml-6">{job.role}</p>
      {job.interviewDate && (
        <div className="flex items-center gap-1 text-xs text-amber-600 mt-2 ml-6">
          <CalendarDays className="w-3 h-3" />
          <span>{new Date(job.interviewDate).toLocaleDateString()}</span>
        </div>
      )}
      {job.notes && (
        <p className="text-xs text-muted-foreground mt-2 ml-6 line-clamp-2 italic">"{job.notes}"</p>
      )}
    </div>
  );
};

export default JobCard;
