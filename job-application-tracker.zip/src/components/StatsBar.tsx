import { JobApplication } from '@/types/job';
import { Briefcase, CalendarCheck, Trophy, XCircle } from 'lucide-react';

interface StatsBarProps {
  jobs: JobApplication[];
}

const StatsBar = ({ jobs }: StatsBarProps) => {
  const total = jobs.length;
  const interviews = jobs.filter(j => j.stage === 'interview').length;
  const offers = jobs.filter(j => j.stage === 'offer').length;
  const rejected = jobs.filter(j => j.stage === 'rejected').length;
  const interviewRate = total > 0 ? Math.round((interviews / total) * 100) : 0;

  const stats = [
    { label: 'Total Apps', value: total, icon: Briefcase, color: 'text-primary' },
    { label: 'Interview Rate', value: `${interviewRate}%`, icon: CalendarCheck, color: 'text-amber-500' },
    { label: 'Offers', value: offers, icon: Trophy, color: 'text-accent' },
    { label: 'Rejected', value: rejected, icon: XCircle, color: 'text-destructive' },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {stats.map(stat => (
        <div key={stat.label} className="bg-card rounded-lg border p-4 flex items-center gap-3">
          <stat.icon className={`w-8 h-8 ${stat.color}`} />
          <div>
            <p className="text-2xl font-display font-bold text-card-foreground">{stat.value}</p>
            <p className="text-sm text-muted-foreground">{stat.label}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default StatsBar;
