import { JobApplication, JobStage, STAGES } from '@/types/job';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useState, useEffect } from 'react';

interface JobDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (job: Omit<JobApplication, 'id'> & { id?: string }) => void;
  onDelete?: (id: string) => void;
  initialJob?: JobApplication | null;
  defaultStage?: JobStage;
}

const JobDialog = ({ open, onOpenChange, onSave, onDelete, initialJob, defaultStage = 'applied' }: JobDialogProps) => {
  const [company, setCompany] = useState('');
  const [role, setRole] = useState('');
  const [stage, setStage] = useState<JobStage>(defaultStage);
  const [notes, setNotes] = useState('');
  const [interviewDate, setInterviewDate] = useState('');

  useEffect(() => {
    if (initialJob) {
      setCompany(initialJob.company);
      setRole(initialJob.role);
      setStage(initialJob.stage);
      setNotes(initialJob.notes);
      setInterviewDate(initialJob.interviewDate || '');
    } else {
      setCompany('');
      setRole('');
      setStage(defaultStage);
      setNotes('');
      setInterviewDate('');
    }
  }, [initialJob, defaultStage, open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...(initialJob ? { id: initialJob.id } : {}),
      company,
      role,
      stage,
      notes,
      interviewDate: interviewDate || undefined,
      appliedDate: initialJob?.appliedDate || new Date().toISOString(),
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display">{initialJob ? 'Edit Application' : 'New Application'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="company">Company</Label>
            <Input id="company" value={company} onChange={e => setCompany(e.target.value)} required />
          </div>
          <div>
            <Label htmlFor="role">Role</Label>
            <Input id="role" value={role} onChange={e => setRole(e.target.value)} required />
          </div>
          <div>
            <Label>Stage</Label>
            <Select value={stage} onValueChange={v => setStage(v as JobStage)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {STAGES.map(s => <SelectItem key={s.key} value={s.key}>{s.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="interviewDate">Interview Date</Label>
            <Input id="interviewDate" type="date" value={interviewDate} onChange={e => setInterviewDate(e.target.value)} />
          </div>
          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea id="notes" value={notes} onChange={e => setNotes(e.target.value)} rows={3} />
          </div>
          <div className="flex gap-2 justify-end">
            {initialJob && onDelete && (
              <Button type="button" variant="destructive" onClick={() => { onDelete(initialJob.id); onOpenChange(false); }}>
                Delete
              </Button>
            )}
            <Button type="submit">{initialJob ? 'Update' : 'Add Application'}</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default JobDialog;
