import { useState, useMemo } from 'react';
import { JobApplication, JobStage, STAGES } from '@/types/job';
import StatsBar from '@/components/StatsBar';
import KanbanColumn from '@/components/KanbanColumn';
import JobDialog from '@/components/JobDialog';
import { Input } from '@/components/ui/input';
import { Search, Briefcase } from 'lucide-react';
import { Button } from '@/components/ui/button';

const SAMPLE_JOBS: JobApplication[] = [
  { id: '1', company: 'Google', role: 'Frontend Engineer', stage: 'applied', notes: 'Referral from John', appliedDate: '2026-03-20' },
  { id: '2', company: 'Meta', role: 'React Developer', stage: 'interview', notes: 'Phone screen done', interviewDate: '2026-04-05', appliedDate: '2026-03-15' },
  { id: '3', company: 'Stripe', role: 'Full Stack Dev', stage: 'offer', notes: 'Offer letter received!', appliedDate: '2026-03-01' },
  { id: '4', company: 'Netflix', role: 'UI Engineer', stage: 'applied', notes: '', appliedDate: '2026-03-28' },
  { id: '5', company: 'Amazon', role: 'SDE II', stage: 'rejected', notes: 'System design round', appliedDate: '2026-02-10' },
];

const Index = () => {
  const [jobs, setJobs] = useState<JobApplication[]>(SAMPLE_JOBS);
  const [filter, setFilter] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingJob, setEditingJob] = useState<JobApplication | null>(null);
  const [defaultStage, setDefaultStage] = useState<JobStage>('applied');
  const [draggedId, setDraggedId] = useState<string | null>(null);

  const filteredJobs = useMemo(() => {
    if (!filter) return jobs;
    const q = filter.toLowerCase();
    return jobs.filter(j => j.company.toLowerCase().includes(q) || j.role.toLowerCase().includes(q));
  }, [jobs, filter]);

  const handleDragStart = (_e: React.DragEvent, jobId: string) => setDraggedId(jobId);

  const handleDrop = (_e: React.DragEvent, stage: JobStage) => {
    if (!draggedId) return;
    setJobs(prev => prev.map(j => j.id === draggedId ? { ...j, stage } : j));
    setDraggedId(null);
  };

  const handleSave = (data: Omit<JobApplication, 'id'> & { id?: string }) => {
    if (data.id) {
      setJobs(prev => prev.map(j => j.id === data.id ? { ...j, ...data } as JobApplication : j));
    } else {
      setJobs(prev => [...prev, { ...data, id: crypto.randomUUID() } as JobApplication]);
    }
  };

  const handleDelete = (id: string) => setJobs(prev => prev.filter(j => j.id !== id));

  const handleAddClick = (stage: JobStage) => {
    setEditingJob(null);
    setDefaultStage(stage);
    setDialogOpen(true);
  };

  const handleEditClick = (job: JobApplication) => {
    setEditingJob(job);
    setDialogOpen(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="container max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-primary rounded-lg p-2">
              <Briefcase className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-display text-xl font-bold text-foreground">Job Application Tracker</h1>
              <p className="text-xs text-muted-foreground">Manage your job hunt with ease</p>
            </div>
          </div>
          <Button onClick={() => { setEditingJob(null); setDefaultStage('applied'); setDialogOpen(true); }}>
            + New Application
          </Button>
        </div>
      </header>

      <main className="container max-w-7xl mx-auto px-4 py-6 space-y-6">
        <StatsBar jobs={jobs} />

        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Filter by company or role..."
            value={filter}
            onChange={e => setFilter(e.target.value)}
            className="pl-9"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {STAGES.map(s => (
            <KanbanColumn
              key={s.key}
              stage={s.key}
              label={s.label}
              jobs={filteredJobs.filter(j => j.stage === s.key)}
              onEdit={handleEditClick}
              onDragStart={handleDragStart}
              onDrop={handleDrop}
              onAddClick={handleAddClick}
            />
          ))}
        </div>
      </main>

      <JobDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        onSave={handleSave}
        onDelete={handleDelete}
        initialJob={editingJob}
        defaultStage={defaultStage}
      />
    </div>
  );
};

export default Index;
