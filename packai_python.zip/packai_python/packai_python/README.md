# PackAI Label Studio — Python Version

A standalone packaging label design app built with Python (Flask) + HTML/CSS/JS.

## Features
- Generate all 4 label faces: Front, Back, Left Side, Right Side
- 6 distinct layout templates, seeded by product name
- 35 colour palettes across 7 design moods
- Smart content per product type (serum, cleanser, candle, tea, perfume, etc.)
- Click any text to edit: font, size, colour, alignment, offset
- Adjust sticker dimensions in cm
- Export print-ready HTML → open in browser → Save as PDF

## Quick Start

```bash
# 1. Install dependency
pip install flask

# 2. Run the app
python app.py

# 3. Open in browser
# http://localhost:5000
```

## Project Structure

```
packai_python/
├── app.py            # Flask server + export builder
├── engine.py         # Design generation algorithm (pure Python)
├── requirements.txt  # Dependencies (just Flask)
└── templates/
    └── index.html    # Full frontend UI
```

## API Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| GET | `/` | Serves the app UI |
| POST | `/api/generate` | Generates design from brief |
| POST | `/api/export` | Returns print-ready HTML file |
| POST | `/api/update_element` | Updates a single element property |
| POST | `/api/update_face` | Updates face background/accent colour |

### POST /api/generate
**Request:**
```json
{
  "brand": "Aura",
  "product": "AquaGlow Face Wash",
  "category": "Skincare",
  "mood": "Minimalist",
  "netWeight": "250ml",
  "keywords": ""
}
```
**Response:**
```json
{
  "ok": true,
  "design": {
    "layout": 2,
    "front": { "bg": "#dce8f0", "accent": "#6fa8c8", ... },
    "back":  { ... },
    "leftSide": { ... },
    "rightSide": { ... }
  }
}
```

### POST /api/export
**Request:**
```json
{
  "design": { ... },
  "sizes": {
    "front":     {"w": 7,   "h": 10.5},
    "back":      {"w": 7,   "h": 10.5},
    "leftSide":  {"w": 2.5, "h": 10.5},
    "rightSide": {"w": 2.5, "h": 10.5}
  }
}
```
**Response:** `text/html` file download (open in Chrome → Print → Save as PDF)

## Algorithm Overview

The design engine in `engine.py` works in 5 steps:

1. **Seed** — `seed = brand + "|" + product` (lowercase)
2. **Hash** — `str_hash(seed)` → deterministic float 0..1 (djb2 polynomial)
3. **Palette** — pick 1 of 5 palettes for the selected mood using hash
4. **Product type** — regex match product name → 14 types → specific content pool
5. **Layout** — `int(str_hash(seed+"layout") * 6)` → 1 of 6 structural templates

Same product + brand always produces identical design. Different products always differ.
