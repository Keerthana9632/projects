"""
PackAI Design Engine — Python version
Same algorithm as the JS version, fully deterministic seeded design generation.
"""
import re
import ctypes

# ─── HASH (same djb2 polynomial as JS) ────────────────────────────────────────
def str_hash(s: str) -> float:
    """Deterministic hash of string → float 0..1 (mirrors JS strHash)"""
    h = 0
    for ch in s:
        # Replicate JS: Math.imul(31, h) + charCode | 0
        h = ctypes.c_int32(ctypes.c_int32(31 * h).value + ord(ch)).value
    return ctypes.c_uint32(h).value / 4294967295.0

def seeded_pick(arr: list, seed: str):
    return arr[int(str_hash(seed) * len(arr))]

# ─── PALETTES ─────────────────────────────────────────────────────────────────
# 7 moods × 5 palettes = 35 total. Each palette: [bg, accent, light, dark]
PALETTES = {
    "Minimalist": [
        ["#dce8f0","#6fa8c8","#f4f8fb","#1e3a4a"],
        ["#f0ede8","#b8a090","#faf8f5","#2e2018"],
        ["#e8e8f0","#8888c8","#f5f5fb","#1a1a3a"],
        ["#e8f0e8","#88b488","#f5fbf5","#1a3a1a"],
        ["#f0e8ee","#c888b0","#fbf5f8","#3a1a2e"],
    ],
    "Luxury": [
        ["#12101e","#c9a96e","#f5f0e8","#08060f"],
        ["#1e0a10","#d4af37","#faf0e0","#0f0508"],
        ["#0a1a10","#4a9060","#e8f5ee","#040e08"],
        ["#1a1030","#a080e0","#f0ecfb","#0a0818"],
        ["#1e1010","#c04040","#faf0f0","#0f0808"],
    ],
    "Earthy / Organic": [
        ["#3d6b4a","#7ab87a","#eef7ee","#1e3a25"],
        ["#6b4a1e","#c4855a","#faf2e8","#3a2010"],
        ["#5a6b3d","#a0b855","#f5f7ee","#2a3a1e"],
        ["#6b5a3d","#c8a870","#faf5e8","#3a2e1a"],
        ["#3d5a6b","#6aaab8","#eef5f7","#1e2e3a"],
    ],
    "Futuristic": [
        ["#060c1e","#00c8f0","#e0f8ff","#020610"],
        ["#10061e","#a020f0","#f0e0ff","#060210"],
        ["#061410","#00e880","#e0fff4","#020a06"],
        ["#1e1006","#f08020","#fff4e0","#100602"],
        ["#06101e","#0080ff","#e0f0ff","#020810"],
    ],
    "Vintage": [
        ["#7a3810","#c87840","#fef5e8","#3e1c08"],
        ["#5a3820","#b09070","#fdf6ee","#2e1c10"],
        ["#3a4820","#788840","#f5f7ee","#1e2410"],
        ["#480828","#a04060","#fef0f4","#280414"],
        ["#204848","#408888","#eef5f5","#102424"],
    ],
    "Playful": [
        ["#ff4488","#ffd700","#fff8f0","#aa0044"],
        ["#ff6020","#40c0ff","#f0f8ff","#aa3000"],
        ["#8040ff","#ff8020","#fff8f0","#400080"],
        ["#00b848","#ff4488","#fff0f8","#005824"],
        ["#ff2020","#20a0ff","#f0f8ff","#aa0000"],
    ],
    "Bold / Graphic": [
        ["#111111","#e83030","#f8f8f8","#000000"],
        ["#001830","#0080ff","#f0f6ff","#000c18"],
        ["#180018","#cc00cc","#fff0ff","#0c000c"],
        ["#181800","#ccaa00","#fffff0","#0c0c00"],
        ["#001800","#00cc44","#f0fff4","#000c00"],
    ],
}

# ─── PRODUCT TYPE DETECTION ───────────────────────────────────────────────────
def detect_product_type(name: str, category: str) -> str:
    n = name.lower()
    if re.search(r'serum|essence', n):         return 'serum'
    if re.search(r'cream|moistur|lotion', n):  return 'cream'
    if re.search(r'cleanser|wash|foam|gel', n):return 'cleanser'
    if re.search(r'mask|peel', n):             return 'mask'
    if re.search(r'toner|mist|spray', n):      return 'toner'
    if re.search(r'\boil\b', n):               return 'oil'
    if re.search(r'coffee|tea|matcha|chai', n):return 'tea'
    if re.search(r'juice|smoothie|drink', n):  return 'drink'
    if re.search(r'protein|supplement|vitamin|capsule', n): return 'supplement'
    if re.search(r'candle', n):                return 'candle'
    if re.search(r'perfume|cologne|eau de', n):return 'perfume'
    if re.search(r'\blip\b', n):               return 'lip'
    if re.search(r'\beye\b', n):               return 'eye'
    if re.search(r'sunscreen|spf', n):         return 'sunscreen'
    return category.lower().split()[0]

# ─── SMART CONTENT LIBRARY ────────────────────────────────────────────────────
SMART = {
    'serum': {
        'taglines': ["Concentrated radiance in every drop.","Science of beautiful skin.",
                     "Your skin's transformation begins here.","Pure potency, visible results."],
        'b1': ["BRIGHTENING","FIRMING","HYDRATING","ANTI-AGING","GLOW BOOST"],
        'b2': ["NOURISHING","PLUMPING","RENEWING","SMOOTHING","RADIANCE"],
        'ing': "Aqua, Niacinamide (10%), Hyaluronic Acid, Sodium Ascorbyl Phosphate (Vitamin C), Glycerin, Panthenol, Retinyl Palmitate, Ceramide NP, Allantoin, Xanthan Gum, Citric Acid, Sodium Benzoate.",
        'dir': "Apply 3–4 drops to clean, dry face. Press gently into skin until absorbed. Use morning and evening. Follow with moisturiser and SPF."
    },
    'cream': {
        'taglines': ["Deeply nourishing, visibly transformed.","Luxury moisture, all day long.",
                     "Your daily dose of skin comfort.","Rich hydration, soft skin."],
        'b1': ["DEEP MOISTURE","24H HYDRATION","BARRIER REPAIR","ANTI-AGING","SOFTENING"],
        'b2': ["NOURISHING","PROTECTIVE","SOOTHING","FIRMING","BRIGHTENING"],
        'ing': "Aqua, Shea Butter, Glycerin, Cetearyl Alcohol, Niacinamide, Hyaluronic Acid, Ceramide NP, Tocopherol (Vitamin E), Allantoin, Panthenol, Phenoxyethanol, Ethylhexylglycerin.",
        'dir': "Take a pea-sized amount and warm between fingertips. Apply to face and neck in upward circular motions. Use morning and/or evening on cleansed skin."
    },
    'cleanser': {
        'taglines': ["Clean start, glowing finish.","The purest clean your skin deserves.",
                     "Gentle power, beautiful skin.","Refresh. Cleanse. Glow."],
        'b1': ["DEEP CLEANSE","PORE CARE","OIL CONTROL","GENTLE","PURIFYING"],
        'b2': ["BALANCING","BRIGHTENING","REFRESHING","NOURISHING","SOOTHING"],
        'ing': "Aqua, Glycerin, Cocamidopropyl Betaine, Sodium Cocoyl Isethionate, Aloe Barbadensis Leaf Juice, Panthenol, Niacinamide, Allantoin, Sodium PCA, Xanthan Gum, Citric Acid, Sodium Benzoate.",
        'dir': "Wet face with lukewarm water. Apply a small amount and massage gently in circular motions for 30–60 seconds. Rinse thoroughly. Use twice daily."
    },
    'oil': {
        'taglines': ["Liquid gold for your skin.","Nourish deep, glow bright.",
                     "Nature's most precious oils, refined.","The luxury your skin craves."],
        'b1': ["NOURISHING","BRIGHTENING","ANTI-AGING","HEALING","RADIANCE"],
        'b2': ["LIGHTWEIGHT","FAST ABSORB","BALANCING","SMOOTHING","FIRMING"],
        'ing': "Squalane, Rosehip Seed Oil (Rosa Canina), Jojoba Oil, Marula Oil, Argan Oil (Argania Spinosa), Vitamin E (Tocopherol), Bakuchiol, Rosemary Extract.",
        'dir': "Warm 3–5 drops between palms. Press gently onto face and neck. Can be mixed with moisturiser or applied alone. Use morning or evening."
    },
    'tea': {
        'taglines': ["Taste the difference, feel the calm.","Every sip, a moment of wellness.",
                     "Handcrafted. Pure. Exceptional.","Nature steeped to perfection."],
        'b1': ["ANTIOXIDANT","ENERGISING","NATURAL","ORGANIC"],
        'b2': ["REFRESHING","CALMING","PURE","WELLNESS"],
        'ing': "Organic Tea Leaves (Camellia Sinensis), Natural Flavouring, Dried Flower Petals, Citric Acid. May contain traces of nuts.",
        'dir': "Heat water to 80°C (not boiling). Steep for 2–3 minutes. Remove tea bag or strain loose leaves. Enjoy with or without milk. Best enjoyed fresh."
    },
    'drink': {
        'taglines': ["Fuel your day, the natural way.","Refreshingly real. Naturally you.",
                     "Pure ingredients. Real taste.","Nourishing every sip."],
        'b1': ["VITAMIN-RICH","NATURAL","ENERGISING","ORGANIC"],
        'b2': ["HYDRATING","REFRESHING","PURE","REAL FRUIT"],
        'ing': "Filtered Water, Fruit Juice (30%), Natural Flavours, Citric Acid, Ascorbic Acid (Vitamin C 80mg), Stevia Leaf Extract. No artificial colours or preservatives.",
        'dir': "Shake well before drinking. Best served chilled. Consume within 3 days of opening. Refrigerate after opening."
    },
    'supplement': {
        'taglines': ["Science-backed. Nature-inspired.","Fuel your potential daily.",
                     "Your body deserves the best.","Precision nutrition, real results."],
        'b1': ["HIGH POTENCY","BIOAVAILABLE","TESTED","PURE"],
        'b2': ["VEGAN","EFFECTIVE","NATURAL","CERTIFIED"],
        'ing': "Active Blend: Magnesium Glycinate 400mg, Zinc Citrate 15mg, Vitamin D3 1000IU, Ashwagandha Extract 300mg. Other: HPMC (capsule), Rice Flour, Magnesium Stearate (vegetable).",
        'dir': "Take 1–2 capsules daily with 200ml of water, preferably with food. Do not exceed stated dose. Consult a healthcare professional before use if pregnant or on medication."
    },
    'candle': {
        'taglines': ["Light up your favourite moments.","Warmth in every flame.",
                     "Scent the air, calm the mind.","Premium fragrance, sustainably made."],
        'b1': ["LONG BURN","NATURAL WAX","HAND POURED","ECO WICK"],
        'b2': ["SOOTHING","AROMATIC","CLEAN BURN","SUSTAINABLE"],
        'ing': "100% Natural Soy Wax, Fragrance Oil Blend (Essential Oils), Cotton Wick. Free from paraffin, phthalates, and artificial dyes.",
        'dir': "Trim wick to 5mm before each use. Allow wax to melt to edges on first burn (2–3 hours). Never burn for more than 4 hours. Always burn on a heat-resistant surface."
    },
    'perfume': {
        'taglines': ["Your signature, beautifully worn.","A scent that tells your story.",
                     "Wear the invisible, feel extraordinary.","Fragrance as unique as you are."],
        'b1': ["LONG LASTING","UNIQUE","FRESH","SENSUAL"],
        'b2': ["SOPHISTICATED","COMPLEX","MODERN","TIMELESS"],
        'ing': "Alcohol Denat. (80%), Parfum (Fragrance), Aqua, Benzyl Benzoate, Linalool, Limonene, Citronellol, Geraniol, Coumarin, Eugenol, Benzyl Salicylate.",
        'dir': "Hold 15–20cm from body. Spray onto pulse points — wrists, neck, behind ears. For best longevity, apply to moisturised skin. Do not rub wrists together."
    },
}

FALLBACK = {
    'taglines': ["Quality you can see and feel.","Crafted with care, made for you.",
                 "Pure. Natural. Effective.","The difference is in the detail."],
    'b1': ["NATURAL","PURE","QUALITY","TRUSTED"],
    'b2': ["EFFECTIVE","GENTLE","CERTIFIED","CRAFTED"],
    'ing': "Natural extracts, Aqua, Glycerin, Citric Acid, Sodium Benzoate, Potassium Sorbate.",
    'dir': "Use as directed. Store in a cool, dry place away from sunlight. Keep out of reach of children."
}

BADGES = [
    "NATURAL • VEGAN • CRUELTY-FREE",
    "DERMATOLOGIST TESTED • VEGAN",
    "ORGANIC • NATURAL • PURE",
    "CLINICALLY TESTED • VEGAN • CRUELTY-FREE",
    "100% NATURAL • ECO CERTIFIED",
]

# ─── ELEMENT DEFAULTS ─────────────────────────────────────────────────────────
ELEM_DEFAULTS = {
    'certBadge':        {'fs':7,  'fw':'600','fi':'normal','ls':'2.5px','tt':'uppercase','ta':'center','ff':'body'},
    'brandName':        {'fs':10, 'fw':'600','fi':'normal','ls':'4px',  'tt':'uppercase','ta':'center','ff':'body'},
    'productName':      {'fs':26, 'fw':'700','fi':'normal','ls':'0',    'tt':'none',     'ta':'center','ff':'display'},
    'tagline':          {'fs':11, 'fw':'300','fi':'italic', 'ls':'0.5px','tt':'none',    'ta':'center','ff':'body'},
    'benefit1':         {'fs':8,  'fw':'500','fi':'normal','ls':'1.5px','tt':'uppercase','ta':'center','ff':'body'},
    'benefit2':         {'fs':8,  'fw':'500','fi':'normal','ls':'1.5px','tt':'uppercase','ta':'center','ff':'body'},
    'netWeight':        {'fs':8,  'fw':'400','fi':'normal','ls':'1px',  'tt':'uppercase','ta':'center','ff':'body'},
    'ingredientsTitle': {'fs':8,  'fw':'700','fi':'normal','ls':'2px',  'tt':'uppercase','ta':'left',  'ff':'body'},
    'ingredientsText':  {'fs':7,  'fw':'400','fi':'normal','ls':'0.2px','tt':'none',     'ta':'left',  'ff':'body'},
    'directionsTitle':  {'fs':8,  'fw':'700','fi':'normal','ls':'2px',  'tt':'uppercase','ta':'left',  'ff':'body'},
    'directionsText':   {'fs':7,  'fw':'400','fi':'normal','ls':'0',    'tt':'none',     'ta':'left',  'ff':'body'},
    'warningsTitle':    {'fs':7,  'fw':'700','fi':'normal','ls':'2px',  'tt':'uppercase','ta':'left',  'ff':'body'},
    'warningsText':     {'fs':6.5,'fw':'400','fi':'normal','ls':'0',    'tt':'none',     'ta':'left',  'ff':'body'},
    'address':          {'fs':7,  'fw':'400','fi':'normal','ls':'0.3px','tt':'none',     'ta':'center','ff':'body'},
    'website':          {'fs':7,  'fw':'600','fi':'normal','ls':'0.5px','tt':'none',     'ta':'center','ff':'body'},
    'batchCode':        {'fs':6,  'fw':'400','fi':'normal','ls':'0.3px','tt':'none',     'ta':'center','ff':'body'},
    'claims':           {'fs':7,  'fw':'600','fi':'normal','ls':'2px',  'tt':'uppercase','ta':'center','ff':'body'},
    'sideProductName':  {'fs':11, 'fw':'700','fi':'normal','ls':'1px',  'tt':'none',     'ta':'center','ff':'display'},
    'sideBrandName':    {'fs':9,  'fw':'600','fi':'normal','ls':'3px',  'tt':'uppercase','ta':'center','ff':'body'},
}

def make_element(elem_id: str, content: str, color: str, overrides: dict = None) -> dict:
    d = dict(ELEM_DEFAULTS.get(elem_id, ELEM_DEFAULTS['brandName']))
    d.update({'content': content, 'color': color, 'ox': 0, 'oy': 0})
    if overrides:
        d.update(overrides)
    return d

# ─── MAIN GENERATE FUNCTION ───────────────────────────────────────────────────
def generate_design(brand: str, product: str, category: str, mood: str,
                    net_weight: str, keywords: str = "") -> dict:
    """
    Generate a complete 4-face label design.
    Returns a dict with layout index + front/back/leftSide/rightSide face data.
    Deterministic: same inputs always produce the same output.
    """
    seed = brand.lower() + "|" + product.lower()

    # 1. Pick colour palette (seeded)
    mood_pals = PALETTES.get(mood, PALETTES["Minimalist"])
    pal_idx   = int(str_hash(seed) * len(mood_pals))
    bg, ac, lt, dk = mood_pals[pal_idx]

    # 2. Detect product type and get smart content
    ptype  = detect_product_type(product, category)
    sc     = SMART.get(ptype, SMART.get(category.lower().split()[0], FALLBACK))

    # 3. Seeded content picks
    tagline  = seeded_pick(sc['taglines'], seed + "tl")
    b1       = seeded_pick(sc['b1'],       seed + "b1")
    b2       = seeded_pick(sc['b2'],       seed + "b2")
    badge    = seeded_pick(BADGES,         seed + "badge")
    ing      = sc['ing']
    direction= sc['dir']

    # 4. Layout template index (0-5)
    layout = int(str_hash(seed + "layout") * 6)

    # 5. Build element data
    brand_up = brand.upper()
    website  = "www." + re.sub(r'\s+', '', brand.lower()) + ".com"

    mk = make_element  # alias

    return {
        "layout": layout,
        "front": {
            "bg": bg, "bg2": ac, "accent": ac, "textColor": dk,
            "elements": {
                "certBadge":   mk("certBadge",   badge,      ac),
                "brandName":   mk("brandName",   brand_up,   dk),
                "productName": mk("productName", product,    dk),
                "tagline":     mk("tagline",     tagline,    dk + "bb"),
                "benefit1":    mk("benefit1",    b1,         ac),
                "benefit2":    mk("benefit2",    b2,         ac),
                "netWeight":   mk("netWeight",   net_weight, dk + "88"),
            }
        },
        "back": {
            "bg": lt, "bg2": lt, "accent": ac, "textColor": dk,
            "elements": {
                "brandName":        mk("brandName",        brand_up,   dk),
                "productName":      mk("productName",      product,    dk,  {"fs": 15}),
                "tagline":          mk("tagline",          tagline,    dk + "99", {"fs": 9}),
                "ingredientsTitle": mk("ingredientsTitle", "INGREDIENTS", ac),
                "ingredientsText":  mk("ingredientsText",  ing,        dk),
                "directionsTitle":  mk("directionsTitle",  "HOW TO USE", ac),
                "directionsText":   mk("directionsText",   direction,  dk),
                "warningsTitle":    mk("warningsTitle",    "⚠ CAUTION","#c0392b"),
                "warningsText":     mk("warningsText",     "Keep away from eyes. Discontinue use if irritation occurs. Keep out of reach of children. Store in a cool, dry place.", "#666"),
                "address":          mk("address",          f"{brand} Co. | hello@{website[4:]}","#aaa"),
                "website":          mk("website",          website,    ac),
                "batchCode":        mk("batchCode",        "LOT-2025-A  |  Mfg: 01/2025  |  Exp: 01/2027","#bbb"),
            }
        },
        "leftSide": {
            "bg": dk, "bg2": dk, "accent": ac, "textColor": lt,
            "elements": {
                "sideBrandName":   mk("sideBrandName",   brand_up,   lt),
                "sideProductName": mk("sideProductName", product,    lt),
                "netWeight":       mk("netWeight",       net_weight, lt + "88"),
            }
        },
        "rightSide": {
            "bg": ac, "bg2": bg, "accent": dk, "textColor": dk,
            "elements": {
                "sideBrandName": mk("sideBrandName", brand_up, dk),
                "claims":        mk("claims",        badge,    dk + "cc"),
                "netWeight":     mk("netWeight",     net_weight, dk + "88"),
            }
        },
    }
