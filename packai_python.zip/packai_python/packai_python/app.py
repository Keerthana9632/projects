"""
PackAI Label Studio — Flask App
Run:  python app.py
Open: http://localhost:5000
"""
from flask import Flask, render_template, request, jsonify, Response
from engine import generate_design
import json, re

app = Flask(__name__)

# ─── EXPORT HTML BUILDER ──────────────────────────────────────────────────────
def build_export_html(design: dict, sizes: dict, gfont: str) -> str:
    """Build the print-ready 3-page A4 export HTML from design data."""
    sf, sb, sl, sr = sizes['front'], sizes['back'], sizes['leftSide'], sizes['rightSide']
    bn = design['front']['elements']['brandName']['content']
    pn = design['front']['elements']['productName']['content']
    layout = design.get('layout', 0)

    def el_style(el, extra=""):
        ff_map = {'display': "'Playfair Display',serif", 'body': "'Jost',sans-serif"}
        ff = ff_map.get(el.get('ff','body'), "'Jost',sans-serif")
        return (
            f"font-family:{ff};font-size:{el['fs']}px;font-weight:{el['fw']};"
            f"font-style:{el['fi']};color:{el['color']};text-align:{el['ta']};"
            f"letter-spacing:{el['ls']};text-transform:{el['tt']};"
            f"transform:translate({el.get('ox',0)}px,{el.get('oy',0)}px);"
            f"line-height:1.38;-webkit-print-color-adjust:exact;print-color-adjust:exact;{extra}"
        )

    def el_div(content, style):
        return f'<div style="{style}">{content}</div>'

    def build_front(w, h):
        f  = design['front']
        e  = f['elements']
        bg, ac = f['bg'], f['accent']
        return f'''<div style="width:{w}cm;height:{h}cm;position:relative;overflow:hidden;
border-radius:3px;background:linear-gradient(150deg,{bg},{ac});
display:flex;flex-direction:column;align-items:center;padding:0 5%;
box-sizing:border-box;-webkit-print-color-adjust:exact;print-color-adjust:exact;">
<div style="position:absolute;top:-15%;right:-15%;width:45%;height:45%;border-radius:50%;background:rgba(255,255,255,.07);"></div>
<div style="width:100%;height:2px;background:linear-gradient(90deg,transparent,{ac},transparent);flex-shrink:0;"></div>
<div style="padding:2% 0;width:100%;display:flex;justify-content:center;">
  {el_div(e['certBadge']['content'], el_style(e['certBadge'],"background:rgba(255,255,255,.18);padding:1% 4%;border-radius:100px;border:1px solid rgba(255,255,255,.3);"))}
</div>
{el_div(e['brandName']['content'], el_style(e['brandName'],"width:100%;margin-bottom:2%;"))}
<div style="width:18%;aspect-ratio:1;border-radius:50%;border:1px solid rgba(255,255,255,.3);
display:flex;align-items:center;justify-content:center;margin:2% 0;flex-shrink:0;">
  <div style="width:70%;aspect-ratio:1;border-radius:50%;background:rgba(255,255,255,.15);"></div>
</div>
{el_div(e['productName']['content'], el_style(e['productName'],"width:100%;margin-bottom:2%;"))}
{el_div(e['tagline']['content'], el_style(e['tagline'],"width:100%;margin-bottom:3%;"))}
<div style="width:50%;height:1px;background:rgba(255,255,255,.3);margin-bottom:3%;"></div>
<div style="display:flex;gap:3%;flex-wrap:wrap;justify-content:center;">
  {el_div(e['benefit1']['content'], el_style(e['benefit1'],"background:rgba(255,255,255,.2);padding:1% 3%;border-radius:100px;border:1px solid rgba(255,255,255,.3);"))}
  {el_div(e['benefit2']['content'], el_style(e['benefit2'],"background:rgba(255,255,255,.2);padding:1% 3%;border-radius:100px;border:1px solid rgba(255,255,255,.3);"))}
</div>
<div style="flex:1;"></div>
<div style="width:100%;border-top:1px solid rgba(255,255,255,.2);padding:2% 0;display:flex;justify-content:center;">
  {el_div(e['netWeight']['content'], el_style(e['netWeight']))}
</div>
</div>'''

    def build_back(w, h):
        b  = design['back']
        e  = b['elements']
        bg, ac = b['bg'], b['accent']
        return f'''<div style="width:{w}cm;height:{h}cm;overflow:hidden;border-radius:3px;
background:{bg};display:flex;flex-direction:column;padding:3% 4% 2%;
box-sizing:border-box;border:1px solid {ac}44;
-webkit-print-color-adjust:exact;print-color-adjust:exact;">
<div style="text-align:center;padding-bottom:2%;border-bottom:1px solid {ac}55;margin-bottom:2%;">
  {el_div(e['brandName']['content'], el_style(e['brandName']))}
  {el_div(e['productName']['content'], el_style(e['productName']))}
  {el_div(e['tagline']['content'], el_style(e['tagline']))}
</div>
<div style="margin-bottom:2%;">
  {el_div("INGREDIENTS", el_style(e['ingredientsTitle'],"margin-bottom:1%;"))}
  {el_div(e['ingredientsText']['content'], el_style(e['ingredientsText'],"line-height:1.5;"))}
</div>
<div style="margin-bottom:2%;">
  {el_div("HOW TO USE", el_style(e['directionsTitle'],"margin-bottom:1%;"))}
  {el_div(e['directionsText']['content'], el_style(e['directionsText'],"line-height:1.5;"))}
</div>
<div style="margin-bottom:2%;">
  {el_div("⚠ CAUTION", el_style(e['warningsTitle'],"margin-bottom:1%;color:#c0392b;"))}
  {el_div(e['warningsText']['content'], el_style(e['warningsText'],"line-height:1.4;"))}
</div>
<div style="flex:1;"></div>
<div style="border-top:1px solid {ac}44;padding-top:2%;display:flex;flex-direction:column;gap:1%;align-items:center;">
  {el_div(e['address']['content'], el_style(e['address']))}
  {el_div(e['website']['content'], el_style(e['website']))}
  {el_div(e['batchCode']['content'], el_style(e['batchCode'],"margin-top:1%;"))}
</div>
</div>'''

    def build_side(face_key, w, h):
        s  = design[face_key]
        e  = s['elements']
        bg, bg2, ac = s['bg'], s.get('bg2', s['bg']), s['accent']
        v  = "writing-mode:vertical-rl;transform:rotate(180deg);"
        claims_html = el_div(e['claims']['content'], el_style(e['claims'], v+"margin-top:5px;")) if 'claims' in e else ''
        return f'''<div style="width:{w}cm;height:{h}cm;overflow:hidden;border-radius:3px;
background:linear-gradient(180deg,{bg},{bg2});display:flex;align-items:center;
justify-content:center;border:1px solid {ac}55;position:relative;
-webkit-print-color-adjust:exact;print-color-adjust:exact;">
<div style="position:absolute;top:4px;left:0;right:0;height:1px;background:linear-gradient(90deg,transparent,{ac},transparent);"></div>
<div style="position:absolute;bottom:4px;left:0;right:0;height:1px;background:linear-gradient(90deg,transparent,{ac},transparent);"></div>
<div style="display:flex;flex-direction:column;align-items:center;gap:5px;">
  {el_div(e['sideBrandName']['content'], el_style(e['sideBrandName'], v))}
  <div style="width:1px;height:14px;background:{ac}55;"></div>
  {el_div(e['sideProductName']['content'], el_style(e['sideProductName'], v))}
  {claims_html}
  {el_div(e['netWeight']['content'], el_style(e['netWeight'], v+"margin-top:4px;"))}
</div>
</div>'''

    wrap = lambda h: f'<div style="display:inline-block;border:1.5px dashed #bbb;padding:3mm;-webkit-print-color-adjust:exact;print-color-adjust:exact;">{h}</div>'

    return f'''<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{bn} — {pn} Labels</title>
<link href="{gfont}" rel="stylesheet">
<style>
*{{box-sizing:border-box;-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important;}}
body{{background:#e8e8f0;margin:0;font-family:'Jost',sans-serif;}}
.tb{{background:#fff;padding:14px 24px;display:flex;align-items:center;justify-content:space-between;
  gap:16px;position:sticky;top:0;box-shadow:0 2px 10px rgba(0,0,0,.08);flex-wrap:wrap;}}
.tb p{{font-size:13px;color:#555;margin:0;line-height:1.7;}}
.btn{{background:linear-gradient(135deg,#6b5bff,#ff6b9d);color:#fff;border:none;padding:12px 24px;
  border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;white-space:nowrap;}}
.pages{{padding:24px;display:flex;flex-direction:column;gap:20px;}}
.page{{width:210mm;min-height:297mm;background:#fff;margin:0 auto;display:flex;flex-direction:column;
  align-items:center;justify-content:center;padding:18mm 15mm;position:relative;
  box-shadow:0 4px 24px rgba(0,0,0,.12);}}
.pgt{{position:absolute;top:9mm;left:0;right:0;text-align:center;font-size:8pt;color:#bbb;
  letter-spacing:.2em;text-transform:uppercase;font-family:'Jost',sans-serif;}}
.pgn{{position:absolute;bottom:6mm;right:12mm;font-size:7pt;color:#ccc;font-family:'Jost',sans-serif;}}
.cut{{position:absolute;bottom:13mm;left:0;right:0;text-align:center;font-size:7pt;color:#bbb;font-family:'Jost',sans-serif;}}
.sr{{display:flex;gap:16mm;align-items:center;justify-content:center;}}
.sw{{display:flex;flex-direction:column;align-items:center;gap:4mm;}}
.sl{{font-size:7pt;color:#bbb;letter-spacing:.15em;text-transform:uppercase;font-family:'Jost',sans-serif;}}
@media print{{
  .tb{{display:none!important;}}
  .pages{{padding:0;}}
  .page{{margin:0;box-shadow:none;page-break-after:always;page-break-inside:avoid;}}
  .page:last-child{{page-break-after:auto;}}
  @page{{size:A4 portrait;margin:0;}}
}}
</style></head><body>
<div class="tb">
  <p>🎉 <strong>{bn} — {pn}</strong> labels ready!<br>
  Click → set <em>Destination</em> to <strong>Save as PDF</strong> → tick <strong>Background graphics</strong>.</p>
  <button class="btn" onclick="window.print()">🖨 Print / Save as PDF</button>
</div>
<div class="pages">
  <div class="page">
    <div class="pgt">FRONT LABEL · {sf['w']}×{sf['h']} cm</div>
    {wrap(build_front(sf['w'], sf['h']))}
    <div class="cut">✂ Cut along dashed border</div>
    <div class="pgn">1 / 3</div>
  </div>
  <div class="page">
    <div class="pgt">BACK LABEL · {sb['w']}×{sb['h']} cm</div>
    {wrap(build_back(sb['w'], sb['h']))}
    <div class="cut">✂ Cut along dashed border</div>
    <div class="pgn">2 / 3</div>
  </div>
  <div class="page">
    <div class="pgt">SIDE LABELS · Left {sl['w']}×{sl['h']}cm | Right {sr['w']}×{sr['h']}cm</div>
    <div class="sr">
      <div class="sw">{wrap(build_side('leftSide', sl['w'], sl['h']))}<span class="sl">LEFT SIDE</span></div>
      <div class="sw">{wrap(build_side('rightSide', sr['w'], sr['h']))}<span class="sl">RIGHT SIDE</span></div>
    </div>
    <div class="cut">✂ Cut along dashed borders</div>
    <div class="pgn">3 / 3</div>
  </div>
</div>
</body></html>'''


# ─── ROUTES ───────────────────────────────────────────────────────────────────
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/generate', methods=['POST'])
def api_generate():
    data = request.get_json()
    try:
        design = generate_design(
            brand      = data.get('brand', ''),
            product    = data.get('product', ''),
            category   = data.get('category', 'Skincare'),
            mood       = data.get('mood', 'Minimalist'),
            net_weight = data.get('netWeight', '50ml'),
            keywords   = data.get('keywords', ''),
        )
        return jsonify({'ok': True, 'design': design})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 400

@app.route('/api/export', methods=['POST'])
def api_export():
    data   = request.get_json()
    design = data.get('design', {})
    sizes  = data.get('sizes', {
        'front':     {'w': 7,   'h': 10.5},
        'back':      {'w': 7,   'h': 10.5},
        'leftSide':  {'w': 2.5, 'h': 10.5},
        'rightSide': {'w': 2.5, 'h': 10.5},
    })
    gfont = "https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400&family=Jost:wght@300;400;500;600;700&display=swap"
    html  = build_export_html(design, sizes, gfont)
    bn    = design.get('front',{}).get('elements',{}).get('brandName',{}).get('content','Package')
    pn    = design.get('front',{}).get('elements',{}).get('productName',{}).get('content','Labels')
    fname = re.sub(r'\s+','_', f"{bn}_{pn}_labels").lower() + ".html"
    return Response(
        html,
        mimetype='text/html',
        headers={'Content-Disposition': f'attachment; filename="{fname}"'}
    )

@app.route('/api/update_element', methods=['POST'])
def api_update_element():
    """Update a single element property and return updated design."""
    data    = request.get_json()
    design  = data['design']
    face    = data['face']
    elem_id = data['elemId']
    prop    = data['prop']
    value   = data['value']
    design[face]['elements'][elem_id][prop] = value
    return jsonify({'ok': True, 'design': design})

@app.route('/api/update_face', methods=['POST'])
def api_update_face():
    """Update face background/accent colour."""
    data   = request.get_json()
    design = data['design']
    face   = data['face']
    prop   = data['prop']
    value  = data['value']
    design[face][prop] = value
    if prop == 'accent':
        design[face]['bg2'] = value
    return jsonify({'ok': True, 'design': design})

if __name__ == '__main__':
    print("\n🎨 PackAI Label Studio (Python)")
    print("   Open http://localhost:5000 in your browser\n")
    app.run(debug=True, port=5000)
